const express = require('express');
const bodyParser = require('body-parser');
const { graphqlExpress, graphiqlExpress } = require('apollo-server-express');
const Dataloader = require('dataloader');

const db = require('./db/connect')();
const crudServices = require('./db/knexDB')(db);
const serviceFactory = require('./serviceFactory')(crudServices);

const usersService = require('./services/usersService')(crudServices);
const accountsService = require('./services/accountsService')(crudServices);
const transactionsService = require('./services/transactionsService')(crudServices);
const entriesService = require('./services/entriesService')(crudServices);

const schema = require('./api/schema');

const SERVER_PORT = process.env.SERVER_PORT || 3000;
const app = express();

function startGraphqlServer(server) {
  server.use(
    '/graphql',
    bodyParser.json(),
    graphqlExpress({
      schema,
      context: {
        services: {
          usersService,
          accountsService,
          entriesService,
          transactionsService,
        },
        loaders: {
          usersByIds: new Dataloader(usersService.getUsersByIdList),
          accountsByIds: new Dataloader(accountsService.getAccountsByUserIdList),
          entriesByIds: new Dataloader(entriesService.getEntriesBytransactionIdList),
          transactionsByIds: new Dataloader(transactionsService.getTransactionByOriginAccountIdList),
        }
      },
      debug: true
    })
  );

  server.use(
    '/graphiql',
    graphiqlExpress({ endpointURL: '/graphql' })
  );

  server.listen(SERVER_PORT, () => {
    console.log(`Server is up on port ${SERVER_PORT}`);
  });
}

startGraphqlServer(app);