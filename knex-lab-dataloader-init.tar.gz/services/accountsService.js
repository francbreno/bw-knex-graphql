module.exports = crudBuilder => {
  const crudServices = crudBuilder('accounts');

  const getAccountsByUserId = (id) =>
    crudServices.getAll().where('user_id', id);

  const getAccountsByUserIdList = (ids) =>
    crudServices.getAll().whereIn('user_id', ids);

  return {
    ...crudServices,
    getAccountsByUserId,
    getAccountsByUserIdList
  };
};