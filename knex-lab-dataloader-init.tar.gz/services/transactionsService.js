module.exports = crudBuilder => {
  const crudServices = crudBuilder('transactions');

  const getLast = () =>
    crudServices.query()
      .limit(1)
      .orderBy('executed_at', 'desc');

  const getTransactionsByOriginAccountId = (id) =>
    crudServices.getAll().where('origin_account_id', id);

  const getTransactionByOriginAccountIdList = (ids) =>
    crudServices.getAll().whereIn('origin_account_id', ids);

  return {
    ...crudServices,
    getLast,
    getTransactionsByOriginAccountId,
    getTransactionByOriginAccountIdList
  };
};