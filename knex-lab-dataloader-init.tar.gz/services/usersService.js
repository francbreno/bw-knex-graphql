module.exports = crudBuilder => {
  const crudServices = crudBuilder('users');

  const getUsersByIdList = (ids) =>
    crudServices.getAll().whereIn('id', ids);

  return {
    ...crudServices,
    getUsersByIdList
  };
};