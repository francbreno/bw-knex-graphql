module.exports = crudBuilder => {
  const crudServices = crudBuilder('entries');

  const getAccountEntries = (account) =>
    crudServices.query()
      .where('account_id', account.id);

  const getEntriesBytransactionId = (id) =>
    crudServices.getAll().where('transaction_id', id);
  
  const getEntriesBytransactionIdList = (ids) =>
    crudServices.getAll().whereIn('transaction_id', ids);

  return {
    ...crudServices,
    getAccountEntries,
    getEntriesBytransactionId,
    getEntriesBytransactionIdList
  };
};